__version__ = "0.0.1.dev202606202033"
githash = "43069721146a9ea2"
datestamp = "202606202033"

__version__ = "0.0.1.dev202607232133"
githash = "1ed3b4861e23d5d9"
datestamp = "202607232133"

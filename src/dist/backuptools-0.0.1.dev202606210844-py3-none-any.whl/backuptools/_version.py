__version__ = "0.0.1.dev202606210844"
githash = "cf76fe8256a38d8a"
datestamp = "202606210844"

__version__ = "0.0.1.dev202606202155"
githash = "bea571e15faf359c"
datestamp = "202606202155"

__version__ = "0.0.1.dev202606202204"
githash = "bea571e15faf359c"
datestamp = "202606202204"

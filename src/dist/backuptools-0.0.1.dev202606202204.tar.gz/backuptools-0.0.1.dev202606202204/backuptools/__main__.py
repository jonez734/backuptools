#!/usr/bin/env python3
import os
import sys

# try:
#     import argcomplete
#     from argcomplete.completers import FilesCompleter
# except ImportError:
argcomplete = None
FilesCompleter = None

from . import lib

SOURCE_BASE = "/home/opencode/data/work"


def project_completer(prefix, **kwargs):
    namespace = kwargs.get("namespace")
    workdir = getattr(namespace, "workdir", None) or SOURCE_BASE
    if not os.path.isdir(workdir):
        return []
    return [
        d
        for d in os.listdir(workdir)
        if os.path.isdir(os.path.join(workdir, d)) and d.startswith(prefix)
    ]


def main():
    parser = lib.buildargs()

    if argcomplete:
        parser.add_argument(
            "projects",
            nargs="+",
            help="project names to backup",
        ).completer = project_completer
        argcomplete.autocomplete(parser)

    args = parser.parse_args()
    lib.runmodule(args, "main", argv=sys.argv[1:])


if __name__ == "__main__":
    main()
